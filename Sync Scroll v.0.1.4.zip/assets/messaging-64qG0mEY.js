function n(e){return chrome.runtime.sendMessage(e)}async function a(e,s){try{return await chrome.tabs.sendMessage(e,s)}catch{return}}export{n as a,a as s};
